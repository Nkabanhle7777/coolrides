﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cool_Rides
{
    internal class HQ
    {
        private CarAssemblyLine carAssemblyLine;
        private MinibusAssemblyLine minibusAssemblyLine;

        public HQ(CarAssemblyLine carAssemblyLine, MinibusAssemblyLine minibusAssemblyLine)
        {
            this.carAssemblyLine = carAssemblyLine;
            this.minibusAssemblyLine = minibusAssemblyLine;
        }

        public void PlaceCarOrder()
        {
            Car car = new Car(Color.Black);
            carAssemblyLine.ReceiveOrder(car);
        }

        public void PlaceMinibusOrder()
        {
            Minibus minibus = new Minibus(Color.White);
            minibusAssemblyLine.ReceiveOrder(minibus);
        }
    }
}
