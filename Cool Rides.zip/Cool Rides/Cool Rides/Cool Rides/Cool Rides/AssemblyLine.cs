﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cool_Rides
{
    abstract class AssemblyLine
    {
        protected PartsFactory partsFactory;
        protected Spraybooth spraybooth;
        protected Queue<Automobile> orders = new Queue<Automobile>();

        protected abstract Automobile CreateAutomobile { get; }

        protected void AssembleAutomobile(Automobile automobile, int assemblyTime)
        {
            Thread.Sleep(assemblyTime);
            automobile.Color = Color;
            spraybooth.PaintAutomobile(automobile);
        }

        public void ReceiveOrder(Automobile automobile)
        {
            orders.Enqueue(automobile);
        }

        public void ProcessOrders()
        {
            while (orders.Count > 0)
            {
                Automobile automobile = orders.Peek();
                AssembleAutomobile(automobile, AssemblyTime);
                orders.Dequeue();
            }
        }

        // Abstract properties to be implemented by derived classes
        protected abstract int AssemblyTime { get; }
        protected abstract Color Color { get; }
    }
}
