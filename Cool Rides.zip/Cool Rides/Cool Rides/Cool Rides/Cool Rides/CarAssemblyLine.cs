﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cool_Rides
{
    internal class CarAssemblyLine : AssemblyLine
    {
        public CarAssemblyLine(PartsFactory partsFactory, Spraybooth spraybooth)
        {
            this.partsFactory = partsFactory;
            this.spraybooth = spraybooth;
        }

        protected override Automobile CreateAutomobile
        {
            get
            {
                Car car = new Car(Color)
                {
                    Chassis = partsFactory.CreateChassis(),
                    Shell = partsFactory.CreateShell(),
                    Wheel = new List<Wheel>
                {
                    partsFactory.CreateWheel(),
                    partsFactory.CreateWheel(),
                    partsFactory.CreateWheel(),
                    partsFactory.CreateWheel()
                },
                    Trim = partsFactory.CreateTrim()
                };

                return car;
            }
                       
        }

        protected override int AssemblyTime => 2000;
        protected override Color Color => Color.Black;
    }
}
