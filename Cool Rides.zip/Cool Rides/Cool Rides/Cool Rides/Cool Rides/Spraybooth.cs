﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cool_Rides
{
    internal class Spraybooth
    {
        public void PaintAutomobile(Automobile automobile)
        {
            // Simulating paint and dry time
            if (automobile is Car)
                Thread.Sleep(5000);
            else if (automobile is Minibus)
                Thread.Sleep(7000);
        }
    }
}
