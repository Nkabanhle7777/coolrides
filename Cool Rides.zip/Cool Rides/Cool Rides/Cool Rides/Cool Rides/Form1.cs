using System.Diagnostics.Metrics;
using System.Drawing.Text;
using System.Security.Cryptography.X509Certificates;
using System.Threading;
using Timer = System.Windows.Forms.Timer;

namespace Cool_Rides
{
    public partial class Form1 : Form
    {
        private HQ hq;

        //car
        private void AddBlackLux()
        {
            string[] wheels = { " Black LUX100 Front Left ",
                                " Black LUX100 Front Right ",
                                " Black LUX100 Back Left ",
                                " Black LUX100 Back Right " };
            
            foreach (string wheel in wheels)
            {
                // Simulate adding a wheel
                Thread.Sleep(2000);
                // Update the UI after adding a wheel
                UpdateUI($"Creating {wheel} wheel");
                
            }

        }
        private void AddWhiteLux()
        {
            string[] wheels = { " White LUX100 Front Left ",
                                " White LUX100 Front Right ",
                                " White LUX100 Back Left ",
                                " White LUX100 Back Right " };
            foreach (string wheel in wheels)
            {
                // Simulate adding a wheel
                Thread.Sleep(2000);
                // Update the UI after adding a wheel
                UpdateUI($"Creating {wheel} Wheel");
            }

        }
        //mini
        private void AddBlackMV500()
        {
            string[] wheels = { " Black MV500 Front Left ",
                                " Black MV500 Front Right ",
                                " Black MV500 Back Left ",
                                " Black MV500 Back Right " };
            foreach (string wheel in wheels)
            {
                // Simulate adding a wheel
                Thread.Sleep(2000);
                // Update the UI after adding a wheel
                UpdateUI2($"Creating {wheel} Wheel");
            }

        }

        private void AddWhiteMV500()
        {
            string[] wheels = { " White MV500 Front Left ",
                                " White MV500 Front Right ",
                                " White MV500 Back Left ",
                                " White MV500 Back Right " };
            foreach (string wheel in wheels)
            {
                // Simulate adding a wheel
                Thread.Sleep(2000);
                // Update the UI after adding a wheel
                UpdateUI2($"Creating {wheel} Wheel");
            }

        }

        //carUI
        private void UpdateUI(string message)
        {
            if (label6.InvokeRequired)
            {
                label6.Invoke(new Action<string>(UpdateUI), message);
            }
            else
            {
                label6.Text = message;
            }
        }
        //miniUi
        private void UpdateUI2(string message)
        {
            if (label8.InvokeRequired)
            {
                label8.Invoke(new Action<string>(UpdateUI2), message);
            }
            else
            {
                label8.Text = message;
            }
        }
        public Form1()
        {
            InitializeComponent();


            // Initialize the system components
            Spraybooth spraybooth = new Spraybooth();
            CarPartsFactory carPartsFactory = new CarPartsFactory();
            MinibusPartsFactory minibusPartsFactory = new MinibusPartsFactory();
            CarAssemblyLine carAssemblyLine = new CarAssemblyLine(carPartsFactory, spraybooth);
            MinibusAssemblyLine minibusAssemblyLine = new MinibusAssemblyLine(minibusPartsFactory, spraybooth);
            hq = new HQ(carAssemblyLine, minibusAssemblyLine);
        }
        public void label2_Click(object sender, EventArgs e)
        {


        }
        private void label6_Click(object sender, EventArgs e)
        {



        }
        private void button1_Click(object sender, EventArgs e)
        {


        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
         
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                AddBlackLux();
            }
            else if (radioButton2.Checked)
            {
              AddWhiteLux();

            }
            else if (radioButton3.Checked)
            {
                Thread thread = new Thread(AddBlackMV500);
                thread.Start();
            }
            else if (radioButton4.Checked)
            {
                Thread thread = new Thread(AddWhiteMV500);
                thread.Start();
            }
           
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
           
        }
    }


}