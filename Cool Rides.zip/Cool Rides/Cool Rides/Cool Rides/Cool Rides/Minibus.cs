﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cool_Rides
{
    internal class Minibus:Automobile
    {
        public Minibus(Color paintColor)
        {
            Chassis Chassis = new Chassis();
            Shell Shell = new Shell();
            List<Wheel> Wheel = new List<Wheel> { new Wheel(), new Wheel(), new Wheel(), new Wheel() };
            Trim Trim = new Trim();
            Color PaintColor = paintColor;
        }

       
    }
}
