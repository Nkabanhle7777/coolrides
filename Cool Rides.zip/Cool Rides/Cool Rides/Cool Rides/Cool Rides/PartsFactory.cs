﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cool_Rides
{
    abstract class PartsFactory
    {
        public abstract Chassis CreateChassis();
        public abstract Shell CreateShell();
        public abstract Wheel CreateWheel();
        public abstract Trim CreateTrim();
    }
}
