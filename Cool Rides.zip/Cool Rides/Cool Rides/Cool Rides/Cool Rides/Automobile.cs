﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;

namespace Cool_Rides
{
    abstract class Automobile
    {
        public Chassis Chassis { get; set; }
        public Shell Shell { get; set; }
        public List<Wheel> Wheel { get; set; }
        public Trim Trim { get; set; }
        public Color Color { get; set; }

    }
    
}
