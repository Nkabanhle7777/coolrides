﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cool_Rides
{
    internal class CarPartsFactory: PartsFactory
    {
        public override Chassis CreateChassis()
        {
            Thread.Sleep(2000); // Simulate chassis creation time
            return new Chassis();
        }

        public override Shell CreateShell()
        {
            Thread.Sleep(2000); // Simulate shell creation time
            return new Shell();
        }

        public override Wheel CreateWheel()
        {
            return new Wheel();
            //Thread.Sleep(500); // Simulate wheel creation time
            //return new Wheel();
        }

        public override Trim CreateTrim()
        {
            Thread.Sleep(1000); // Simulate interior trim creation time
            return new Trim();
        }
    }
}
